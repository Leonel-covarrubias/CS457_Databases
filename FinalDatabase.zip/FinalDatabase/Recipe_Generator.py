
import psycopg
import re

user_Id = 30172

def main():
    
    connection = psycopg.connect('host=localhost port=5432 dbname=postgres user=postgres password=Lap80lag')

    # Create a cursor
    
    cursor = connection.cursor()
    connection.autocommit = True
    
    while True:
        print("-------RECIPE GENERATOR-------")
        user_input = input("Exit: 0\nMy Favorites: 1\nFind Recipies: 2\nSearch: 3\n>")

        if not user_input.isdigit():
            print("Invalid input. Please enter a valid number.")
            continue
        user_input = int(user_input)


        if user_input == 0:
            print("Exiting...")
            break
        elif user_input == 1:
            display_favorites(cursor, 30172)
        elif user_input == 2:
            get_recipes(cursor)
            user_input2 = input("Main Menu: 0 \nEnter in Recipe ID: ")
            if not user_input2.isdigit():
                print("Invalid input. Please enter a valid number.")
                continue
            if user_input2 == 0:
                continue
            else:
                recipeDetails(cursor, user_input2)
        elif user_input == 3:
            search(cursor)
                
                 


    # Close the cursor and connection
    cursor.close()
    connection.close()

# Function to get stats
def get_recipes(cursor):
    # Execute the SQL query for statistics
    ingredients = []  
    print("Enter your 5 Main Ingredients:\n")
    for i in range(5):
        while True:
            ingredient = input(f"Enter Ingredient {i + 1}: ")

            # Check if the input is valid
            if is_valid_input(ingredient):
                # Append the ingredient to the array
                ingredients.append(ingredient)
                break
            else:
                print("Invalid input. Please enter a valid ingredient.")

    # Build the SQL query with parameterized inputs
    query = """
        SELECT i.id, r.recipe_name, i.ing
        FROM ingredients i
        JOIN recipe r ON i.id = r.id
        WHERE {}
    """.format(" AND ".join("i.ing LIKE %s" for _ in ingredients))

    # Execute the query with user-inputted parameters
    cursor.execute(query, ['%' + ingredient + '%' for ingredient in ingredients])

    # Fetch the results
    results = cursor.fetchall()
    print("Results:\n\n")
    for row in results:
        
        print(f"Recipe ID:   {row[0]}\nRecipe Name: {row[1]}\nIngredients:{row[2]}\n")

 
def is_valid_input(user_input):
    # checks the user input for sql commands 
    valid_pattern = re.compile(r'^[a-zA-Z0-9 ]+(?:,[a-zA-Z0-9 ]+)*$')
    return bool(valid_pattern.match(user_input))

def recipeDetails(cursor, food_id):
    cursor.execute("""
            SELECT
            r.recipe_name,
            s.num_steps,
            s.steps
        FROM
            recipe r
        JOIN
            step s ON r.id = s.id
                   
        WHERE
        r.id = %s;
    """, (food_id,))


    results = cursor.fetchall()

    for row in results:
        print(f"\n\nRecipe Name: {row[0]}\nNumber Of Steps: {row[1]}\nInstructions: {row[2]}\n")
    
    user_input = input("Main Menu: 0 \nAdd to Favorites: 1\nNutritional Information: 2\n> ")
            
    if not user_input.isdigit():
        print("Invalid input. Please enter a valid number.")
    user_input = int(user_input)
    if user_input == 0:
        return
    elif user_input == 1:
        
        addTofavorite(cursor, user_Id,food_id)
    elif user_input == 2:
        getNutrition(cursor, food_id)

def addTofavorite(cursor, user_id, food_id):
    # Fetch the last entryID from favorites
    cursor.execute("""
        SELECT "entryID"
        FROM favorites
        ORDER BY "entryID" DESC
        LIMIT 1;
    """)
    last_entry = cursor.fetchone()

    # Determine the new entryID
    if last_entry:
        entry = last_entry[0] + 1
    else:
        entry = 1

    # Insert into favorites
    
    cursor.execute("""
        INSERT INTO public.favorites("entryID", user_id, favorite_food_id)
        VALUES (%s, %s, %s);
    """, (entry, user_id, food_id))
    
def display_favorites(cursor, userid):
    
    userid = str(userid)
    cursor.execute("""
        SELECT f.favorite_food_id, r.recipe_name
        FROM favorites f
        JOIN recipe r ON f.favorite_food_id = CAST(r.id AS VARCHAR)
        WHERE f.user_id = %s;
    """, (userid,))

    results = cursor.fetchall()

    for row in results:
        print(f"Favorite Food ID: {row[0]}\nRecipe Name: {row[1]}\n")

def getNutrition(cursor, food_id):
    food_id = str(food_id)
    cursor.execute("""
                        select nutrition.nutrition
                        from nutrition where id = %s;""",(food_id,))
    results = cursor.fetchall()
    for row in results:
        print(f"Nutrition: (Calories, Total Fat, Sugar, Sodium, Protien, Sat Fat) \n    {row[0]}\n")

def search(cursor):
    food_id = input("Enter Food ID to Search: \n>")
    if is_valid_input (food_id):
        food_id = str(food_id)
        cursor.execute("""
                        SELECT * 
                        FROM search_food 
                        WHERE id = %s""",(food_id,))
        results = cursor.fetchall()
        for row in results:
            print(f"\nRecipe ID: {row[0]}\nRecipe Name: {row[1]}\nMiniutes: {row[2]}\nIngredients: {row[3]}\n\nInstructions: {row[4]}\n\nNutrition: (Calories, Total Fat, Sugar, Sodium, Protien, Sat Fat)\n    {row[5]}\n")
    else: 
        print("invalid Search ")
if __name__ == "__main__":
    main()
