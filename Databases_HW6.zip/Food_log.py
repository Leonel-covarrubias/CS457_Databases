
import psycopg

def main():
    
    connection = psycopg.connect('host=localhost port=5432 dbname=postgres user=postgres password=Lap80lag')

    # Create a cursor

    cursor = connection.cursor()
    connection.autocommit = True
    entry = 13
    print("--------FOOD LOG---------\nSelect from the menu or enter a Food ID: ")
    
    while True:
        user_input = input("Exit: 0\nGet Stats: 1\nEnter Food ID: ")

        if not user_input.isdigit():
            print("Invalid input. Please enter a valid number.")
            continue

        user_input = int(user_input)

        if user_input == 0:
            print("Exiting...")
            break
        elif user_input == 1:
            
            date = input("Enter Date for stats (yyyy-mm-dd): ")

            #Username for this user is 30171 
            getstats(cursor, 30171, date)

        elif 319874 <= user_input <= 2648874:
            date = input("Enter Date (yyyy-mm-dd): ")
            entry = entry + 1 
            logfood(entry,cursor, user_input, date,30171)
            print("Food Successfully Logged!\n")
        else:
            print("Invalid Food ID")

    # Close the cursor and connection
    cursor.close()
    connection.close()

# Function to get stats
def getstats(cursor, user_id, date):
    # Execute the SQL query for statistics
    cursor.execute("""
        SELECT
            user_id,
            date,
            COALESCE(SUM(amount) FILTER (WHERE nutrient_id = 1003), 0) AS total_protein,
            COALESCE(SUM(amount) FILTER (WHERE nutrient_id = 1005), 0) AS total_carbs,
            COALESCE(SUM(amount) FILTER (WHERE nutrient_id = 1008), 0) AS total_cals
        FROM
            user_log
        LEFT JOIN
            food_nutrient ON user_log.food_id = food_nutrient.fdc_id 
        WHERE
            user_id = %s AND date = %s
        GROUP BY
            user_id, date;
    """, (user_id, date))

    # Fetch the results
    results = cursor.fetchall()

    # print the results
    for row in results:
        print(f"User ID: {row[0]}, Date: {row[1]}, Total Protein: {row[2]}, Total Carbs: {row[3]}, Total Calories: {row[4]}")

#
def logfood(entry,cursor, food_id, log_date,user):
    # Execute the SQL query to insert into user_log
    cursor.execute("""
        INSERT INTO user_log (entry_id,food_id, date,user_id) 
        VALUES (%s, %s,%s,%s) 
    """, (entry,food_id, log_date,user))

   

    print(f"Food {food_id} logged on {log_date} with Entry ID {user}")

if __name__ == "__main__":
    main()
